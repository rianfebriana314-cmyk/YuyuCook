function beliProduk(nama, harga) {
    alert("Anda membeli " + nama + " seharga Rp " + harga.toLocaleString());
}